# Reform Workshop

เว็บภาษาไทยสำหรับคำนวณ Enhancement Stone ใน Ragnarok Online ตามสูตร [iRO Wiki — Item Reform](https://irowiki.org/wiki/Item_Reform#Materials) ตรวจสอบ 5 กันยายน 2026

## เปิดใช้งาน

เปิด `index.html` ได้โดยตรง หรือใช้ Node.js รัน `npm start` แล้วเปิด http://127.0.0.1:4173 เพื่อให้ local storage ทำงานบน origin ที่แน่นอน ไม่ต้องติดตั้ง dependencies

## ขึ้น GitHub Pages

1. นำ `index.html`, `styles.css`, `calculator.js`, `app.js` และ `.nojekyll` พร้อมโฟลเดอร์ `assets` ไว้ที่ root ของ repository
2. เปิด repository → Settings → Pages
3. เลือก Deploy from a branch → main → / (root) → Save
4. รอ GitHub Pages deploy แล้วใช้ URL ที่ GitHub แสดง

ทุก asset ใช้ relative path จึงรองรับทั้ง `username.github.io` และ `username.github.io/repository/` ไม่มี backend หรือ build step ฟอนต์ Google Fonts เป็น optional และมี system font สำรอง

## การคำนวณ

- รองรับ Weapon / Armor / Accessory และ Low / Medium / High / Supreme
- ราคาซื้อรองรับวัตถุดิบดรอปและ Accessory Enhancement Stone (Low Grade) จากตลาด
- โหมดต้นทุนต่ำสุดใช้ Stone ในคลัง แล้วเลือกผสม Low Ore, Medium Ore และ Shadowdecon เพื่อให้เงินจ่ายเพิ่มต่ำที่สุด
- โหมด Shadowdecon ใช้ Stone ในคลังและ Shadowdecon / Shadowdecon Ore โดยไม่ใช้ Enhancement Ore
- คำนวณด้วยจำนวนเต็ม รวมเศษ Ore ที่มีแล้วได้ เช่น มี 19 Ore จะซื้อเพิ่มเพียง 1 เพื่อรวมเป็น 1 Shadowdecon หากคุ้มกว่า
- ก้อนสำเร็จรูปในคลังถูกใช้ก่อนรวมจาก Ore; ของในคลังคิดต้นทุนเพิ่มเป็นศูนย์ ไม่รวมมูลค่าขายต่อหรือต้นทุนเดิม
- ราคาเว้นว่างหรือ 0 = ยังไม่ระบุราคา ไม่ซื้อเพิ่ม แต่ใช้ของในคลังได้; หากไม่มีเส้นทางซื้อครบ จะแสดงรอราคาแทนยอดรวมที่ไม่ครบ ราคา 0 ที่เคยบันทึกไว้จะถูกอ่านเป็นช่องว่างเมื่อเปิดหน้าเว็บใหม่
- เป้าหมายสูงสุด 10,000 อัน คลังสูงสุด 1,000,000,000 ชิ้น ราคาสูงสุด 1,000,000,000,000 z ต่อชิ้น (JavaScript floating point; ราคาสูงมากอาจมีความคลาดเคลื่อนระดับเศษหน่วย)
- เก็บราคา คลัง และเป้าหมายใน browser local storage คีย์ `reform-workshop.v1` แยกคลังตามประเภทหิน ไม่ส่งข้อมูลไป server และไม่หักคลังจริงเมื่อคำนวณ
- การรวมแร่ใช้ 20 Ore ต่อก้อน ไม่มีค่าแลก ตามเงื่อนไขผู้ใช้
- Rough Shadowdecon ในภาพผู้ใช้ถือเป็น Shadowdecon Ore
- ราคาตัวอย่าง Weapon Enhancement Ore: Low Grade 8,000 z และ Medium Grade 18,890 z; Armor Enhancement Ore: Low Grade 8,889 z และ Medium Grade 23,000 z; Accessory Enhancement Ore (Low Grade) 7,800 z; Accessory Enhancement Stone: Low Grade 34,990 z, Medium Grade 117,500 z, High Grade 399,000 z และ Supreme Grade 1,500,000 z; Shadowdecon 19,000 z และ Rough Shadowdecon 950 z มาจากภาพผู้ใช้ ไม่ใช่ราคาสดและไม่จำกัดตาม stock ของร้านในภาพ
- อัปเดตราคาเริ่มต้น Weapon และ Armor Low/Medium Ore, Accessory Low Ore และ Accessory Stone ทุกระดับ ให้ข้อมูลเดิมที่ยังไม่ระบุราคาหนึ่งครั้ง โดยคงราคาที่กรอกไว้แล้ว และยังล้างราคาเองได้ภายหลัง
- ราคาเริ่มต้น Rough Shadowdecon เดิม 1,500 z จะอัปเดตเป็น 950 z หนึ่งครั้ง ส่วนค่าที่ตั้งเป็นราคาอื่นจะคงไว้
- โหมดต้นทุนต่ำสุดเปรียบเทียบการซื้อ Accessory Stone ทุกระดับโดยตรงกับการแลกจาก Ore หรือ Shadowdecon ส่วนโหมด Shadowdecon จะไม่ซื้อ Stone โดยตรง

## ตัวอย่างตรวจสอบ

Accessory Supreme 100 อัน เริ่มจากศูนย์และใช้ Shadowdecon:

| ขั้น | จำนวนผลผลิต | ค่า NPC รวม |
|---|---:|---:|
| Shadowdecon → Low | 2,700 | 54,000,000 z |
| Low → Medium | 900 | 9,000,000 z |
| Medium → High | 300 | 6,000,000 z |
| High → Supreme | 100 | 5,000,000 z |

ค่า NPC 74,000,000 z + Shadowdecon 2,700 × 19,000 z = **125,300,000 z**

เมื่อใช้โหมดต้นทุนต่ำสุดกับราคาตัวอย่างปัจจุบัน ระบบจะซื้อ Accessory Low Stone 2,700 ชิ้น × 34,990 z แล้วแลกต่อเป็น Medium / High / Supreme ค่าไอเท็ม 94,473,000 z + ค่า NPC 20,000,000 z = **114,473,000 z**

## ตรวจสอบสูตร

`npm test` ทดสอบตัวอย่างจริง คลังบางส่วน ราคาว่าง/ศูนย์ การแยกประเภท และเทียบตัวเลือกต้นทุนต่ำสุดกับ exhaustive search สำหรับกรณีสุ่มที่ทำซ้ำได้

## รูปไอเท็ม

รูป PNG ทั้ง 20 ไอเท็มอยู่ใน `assets/items/` โหลดจาก [Divine Pride](https://www.divine-pride.net/) โดยตรวจ Item ID ตามสูตร iRO Wiki แสดงด้วยขนาด 24 × 24 px และพื้นหลังโปร่งใส ไม่ต้องโหลดจากเว็บไซต์อื่นขณะใช้งาน รูปเกมเป็นทรัพย์สินของเจ้าของสิทธิ์เดิม URL ต้นทางแต่ละรูปอยู่ใน `assets/items/sources.json`

## คัดลอกชื่อไอเท็ม

คลิกชื่อในคลัง ตารางราคา รายการซื้อ ผลลัพธ์ หรือแผนแลก เพื่อคัดลอกชื่อเต็มภาษาอังกฤษ โดยไม่มีจำนวนหรือราคา ใช้ Enter/Space ได้ด้วย ไอเท็มแร่ใช้ชื่อในเกม Rough Shadowdecon รองรับ Clipboard API บน HTTPS/localhost และมีวิธีสำรองสำหรับการเปิดไฟล์โดยตรง หากเบราว์เซอร์ไม่ยอมให้คัดลอกจะแสดงชื่อให้คัดลอกเอง
