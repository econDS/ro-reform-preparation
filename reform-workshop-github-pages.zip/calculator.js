(function (root) {
  'use strict';
  const TYPES = ['weapon', 'armor', 'accessory'];
  const GRADES = ['Low', 'Medium', 'High', 'Supreme'];
  const number = value => Number.isFinite(Number(value)) && Number(value) >= 0 ? Number(value) : 0;
  const price = value => value === '' || value == null || !Number.isFinite(Number(value)) || Number(value) <= 0 ? Infinity : Number(value);
  const count = value => Math.floor(number(value));
  const materialKeys = TYPES.flatMap(t => [`${t}OreLow`, `${t}OreMedium`]).concat(['accessoryStone0', 'accessoryStone1', 'accessoryStone2', 'accessoryStone3', 'shadowOre', 'shadow']);
  const inventoryKeys = TYPES.flatMap(t => GRADES.map((_, i) => `${t}Stone${i}`).concat([`${t}OreLow`, `${t}OreMedium`])).concat(['shadowOre', 'shadow']);
  function defaults() {
    return {type: 'accessory', grade: 3, quantity: 100, mode: 'auto',
      prices: Object.fromEntries(materialKeys.map(k => [k,
        k === 'weaponOreLow' ? 8000 :
        k === 'weaponOreMedium' ? 18890 :
        k === 'armorOreLow' ? 8889 :
        k === 'armorOreMedium' ? 23000 :
        k === 'accessoryOreLow' ? 7800 :
        k === 'accessoryStone0' ? 34990 :
        k === 'accessoryStone1' ? 117500 :
        k === 'accessoryStone2' ? 399000 :
        k === 'accessoryStone3' ? 1500000 :
        k === 'shadow' ? 19000 :
        k === 'shadowOre' ? 950 : ''])),
      inventory: Object.fromEntries(inventoryKeys.map(k => [k, 0]))};
  }
  function sanitize(raw) {
    const d = defaults();
    if (!raw || typeof raw !== 'object') return d;
    if (TYPES.includes(raw.type)) d.type = raw.type;
    if ([0,1,2,3].includes(Number(raw.grade))) d.grade = Number(raw.grade);
    d.quantity = Math.min(10000, Math.max(0, count(raw.quantity ?? 100)));
    d.mode = raw.mode === 'shadow' ? 'shadow' : 'auto';
    for (const k of materialKeys) d.prices[k] = price(raw.prices?.[k] ?? d.prices[k]) === Infinity ? '' : Math.min(1e12, number(raw.prices?.[k] ?? d.prices[k]));
    for (const k of inventoryKeys) d.inventory[k] = Math.min(1e9, count(raw.inventory?.[k]));
    return d;
  }
  // Each source has a nondecreasing marginal cost. Merge those streams to
  // minimize cash spending, including partial ore bundles and existing stock.
  function calculate(input, empty = false) {
    const s = sanitize(input), t = s.type, inv = empty ? {} : s.inventory;
    const stock = k => count(inv[k]);
    const p = k => price(s.prices[k]);
    const steps = {shadow:0, lowOre:0, mediumOre:0, lowUpgrade:0, highUpgrade:0, supremeUpgrade:0, combineShadow:0};
    const used = {}, buy = {};
    const add = (obj, key, n) => { if (n) obj[key] = (obj[key] || 0) + n; };
    let fees = 0, materialCost = 0;
    function consume(k, n) { const owned = Math.min(stock(k), n); add(used,k,owned); add(buy,k,n-owned); return n-owned; }
    const maxHigh = s.grade === 3 ? s.quantity*3 : s.grade === 2 ? s.quantity : 0;
    const maxMedium = s.grade >= 2 ? maxHigh*3 : s.grade === 1 ? s.quantity : 0;
    const maxLow = s.grade === 0 ? s.quantity : maxMedium*3;
    let lowOreN = 0, shadowN = 0, roughN = 0, directN = 0;
    const lowChoices = [], lowPrefix = [0];
    function nextShadow() {
      if (shadowN < stock('shadow')) return {cost:20000, source:'shadowOwned'};
      const roughMissing = Math.max(0, 20*(roughN+1)-stock('shadowOre')) - Math.max(0,20*roughN-stock('shadowOre'));
      const roughCost = roughMissing === 0 ? 0 : roughMissing * p('shadowOre');
      return roughCost < p('shadow') ? {cost:20000+roughCost, source:'rough'} : {cost:20000+p('shadow'), source:'direct'};
    }
    for (let i=0; i<maxLow; i++) {
      if (i < stock(`${t}Stone0`)) { lowChoices.push('owned'); lowPrefix.push(lowPrefix[i]); continue; }
      const missing = Math.max(0,5*(lowOreN+1)-stock(`${t}OreLow`))-Math.max(0,5*lowOreN-stock(`${t}OreLow`));
      const oreCost = s.mode === 'shadow' ? Infinity : 10000 + (missing === 0 ? 0 : missing*p(`${t}OreLow`));
      const marketCost = s.mode === 'shadow' ? Infinity : p(`${t}Stone0`);
      const shadow = nextShadow();
      if (marketCost < oreCost && marketCost < shadow.cost) { lowChoices.push('marketLow'); lowPrefix.push(lowPrefix[i]+marketCost); }
      else if (oreCost < shadow.cost) { lowOreN++; lowChoices.push('ore'); lowPrefix.push(lowPrefix[i]+oreCost); }
      else { shadowN++; if (shadow.source==='rough') roughN++; if(shadow.source==='direct') directN++; lowChoices.push(shadow.source); lowPrefix.push(lowPrefix[i]+shadow.cost); }
    }
    const mediumChoices=[], mediumPrefix=[0];
    let buildLowCount=0, buildMediumOres=0;
    for (let i=0; i<maxMedium; i++) {
      if(i<stock(`${t}Stone1`)){mediumChoices.push('ownedMedium');mediumPrefix.push(mediumPrefix[i]);continue;}
      const missing = Math.max(0,5*(buildMediumOres+1)-stock(`${t}OreMedium`))-Math.max(0,5*buildMediumOres-stock(`${t}OreMedium`));
      const oreCost = s.mode === 'shadow' ? Infinity : 20000+(missing===0 ? 0 : missing*p(`${t}OreMedium`));
      const marketCost = s.mode === 'shadow' ? Infinity : p(`${t}Stone1`);
      const upgradeCost = 10000 + lowChoices.slice(buildLowCount,buildLowCount+3).reduce((sum, _, j) => {
        const a=lowPrefix[buildLowCount+j], b=lowPrefix[buildLowCount+j+1];
        return sum + (b===Infinity ? Infinity : b-a);
      },0);
      if (marketCost < oreCost && marketCost < upgradeCost) {mediumChoices.push('marketMedium');mediumPrefix.push(mediumPrefix[i]+marketCost);}
      else if (oreCost < upgradeCost) {buildMediumOres++;mediumChoices.push('mediumOre');mediumPrefix.push(mediumPrefix[i]+oreCost);}
      else {buildLowCount+=3;mediumChoices.push('lowUpgrade');mediumPrefix.push(mediumPrefix[i]+upgradeCost);}
    }
    const highChoices=[],highPrefix=[0];
    let buildMediumCount=0;
    for(let i=0;i<maxHigh;i++){
      if(i<stock(`${t}Stone2`)){highChoices.push('ownedHigh');highPrefix.push(highPrefix[i]);continue;}
      const marketCost=s.mode==='shadow'?Infinity:p(`${t}Stone2`);
      const upgradeCost=20000+mediumChoices.slice(buildMediumCount,buildMediumCount+3).reduce((sum,_,j)=>{
        const a=mediumPrefix[buildMediumCount+j],b=mediumPrefix[buildMediumCount+j+1];
        return sum+(b===Infinity?Infinity:b-a);
      },0);
      if(marketCost<upgradeCost){highChoices.push('marketHigh');highPrefix.push(highPrefix[i]+marketCost);}
      else{buildMediumCount+=3;highChoices.push('highUpgrade');highPrefix.push(highPrefix[i]+upgradeCost);}
    }
    let highCount=s.grade===2?s.quantity:0,ownedSupreme=0,boughtSupreme=0;
    if(s.grade===3)for(let i=0;i<s.quantity;i++){
      if(i<stock(`${t}Stone3`)){ownedSupreme++;continue;}
      const marketCost=s.mode==='shadow'?Infinity:p(`${t}Stone3`);
      const upgradeCost=50000+highChoices.slice(highCount,highCount+3).reduce((sum,_,j)=>{
        const a=highPrefix[highCount+j],b=highPrefix[highCount+j+1];
        return sum+(b===Infinity?Infinity:b-a);
      },0);
      if(marketCost<upgradeCost)boughtSupreme++;
      else{highCount+=3;steps.supremeUpgrade++;}
    }
    add(used,`${t}Stone3`,ownedSupreme);add(buy,`${t}Stone3`,boughtSupreme);
    let mediumCount=s.grade===1?s.quantity:0, ownedHigh=0, boughtHigh=0;
    for(let i=0;i<highCount;i++){
      const c=highChoices[i];
      if(c==='ownedHigh')ownedHigh++;else if(c==='marketHigh')boughtHigh++;else{steps.highUpgrade++;mediumCount+=3;}
    }
    add(used,`${t}Stone2`,ownedHigh);add(buy,`${t}Stone2`,boughtHigh);
    let ownedMedium=0,boughtMedium=0,mediumOres=0,lowCount=s.grade===0?s.quantity:0;
    for(let i=0;i<mediumCount;i++){
      const c=mediumChoices[i];
      if(c==='ownedMedium')ownedMedium++;else if(c==='marketMedium')boughtMedium++;else if(c==='mediumOre')mediumOres++;else{steps.lowUpgrade++;lowCount+=3;}
    }
    add(used,`${t}Stone1`,ownedMedium);add(buy,`${t}Stone1`,boughtMedium);
    let ownedLow=0, boughtLow=0, oreLow=0, ownedShadow=0, rough=0, direct=0;
    for (let i=0;i<lowCount;i++) {
      const c=lowChoices[i];
      if(c==='owned') ownedLow++; else if(c==='marketLow') boughtLow++; else if(c==='ore') oreLow++; else if(c==='rough') rough++; else if(c==='direct') direct++; else ownedShadow++;
    }
    add(used,`${t}Stone0`,ownedLow);
    add(buy,`${t}Stone0`,boughtLow);
    steps.lowOre=oreLow; steps.mediumOre=mediumOres; steps.shadow=ownedShadow+rough+direct; steps.combineShadow=rough;
    consume(`${t}OreLow`,oreLow*5); consume(`${t}OreMedium`,mediumOres*5);
    add(used,'shadow',ownedShadow); consume('shadowOre',rough*20); add(buy,'shadow',direct);
    fees += oreLow*10000 + mediumOres*20000 + steps.shadow*20000 + steps.lowUpgrade*10000 + steps.highUpgrade*20000 + steps.supremeUpgrade*50000;
    const missingPrices = [];
    for (const [key,n] of Object.entries(buy)) { if(p(key)===Infinity) missingPrices.push(key); else materialCost+=n*p(key); }
    return {steps, used, buy, fees, materialCost, total:missingPrices.length ? null : fees+materialCost,
      missingPrices, shadowRequired:steps.shadow, shadowAdditional:rough+direct,
      remaining:Object.fromEntries(Object.entries(inv).map(([k,n])=>[k,Math.max(0,n-(used[k]||0))]))};
  }
  function comparison(s) {
    const direct=price(s.prices.shadow), ore=price(s.prices.shadowOre);
    return {direct:Number.isFinite(direct)?direct:null, combined:Number.isFinite(ore)?ore*20:null,
      breakEven:Number.isFinite(direct)?direct/20:null};
  }
  const api={TYPES,GRADES,materialKeys,inventoryKeys,defaults,sanitize,calculate,comparison};
  if(typeof module!=='undefined' && module.exports) module.exports=api;
  root.Reform=api;
})(typeof globalThis!=='undefined'?globalThis:this);
