'use strict';
const R = window.Reform;
const STORAGE_KEY = 'reform-workshop.v1';
let state = R.defaults();
let storageAvailable = true;
try {
  const saved = localStorage.getItem(STORAGE_KEY);
  if(saved) state = R.sanitize(JSON.parse(saved));
  // Apply the new default once to unpriced inventories, preserving custom prices
  // and allowing the user to clear this price again afterwards.
  const defaultUpdateKey = STORAGE_KEY + '.default-weaponOreLow-8000';
  if(!localStorage.getItem(defaultUpdateKey)) {
    if(state.prices.weaponOreLow === '') state.prices.weaponOreLow = 8000;
    localStorage.setItem(STORAGE_KEY,JSON.stringify(state));
    localStorage.setItem(defaultUpdateKey,'1');
  }
  const mediumDefaultUpdateKey = STORAGE_KEY + '.default-weaponOreMedium-18890';
  if(!localStorage.getItem(mediumDefaultUpdateKey)) {
    if(state.prices.weaponOreMedium === '') state.prices.weaponOreMedium = 18890;
    localStorage.setItem(STORAGE_KEY,JSON.stringify(state));
    localStorage.setItem(mediumDefaultUpdateKey,'1');
  }
  const armorLowDefaultUpdateKey = STORAGE_KEY + '.default-armorOreLow-8889';
  if(!localStorage.getItem(armorLowDefaultUpdateKey)) {
    if(state.prices.armorOreLow === '') state.prices.armorOreLow = 8889;
    localStorage.setItem(STORAGE_KEY,JSON.stringify(state));
    localStorage.setItem(armorLowDefaultUpdateKey,'1');
  }
  const armorMediumDefaultUpdateKey = STORAGE_KEY + '.default-armorOreMedium-23000';
  if(!localStorage.getItem(armorMediumDefaultUpdateKey)) {
    if(state.prices.armorOreMedium === '') state.prices.armorOreMedium = 23000;
    localStorage.setItem(STORAGE_KEY,JSON.stringify(state));
    localStorage.setItem(armorMediumDefaultUpdateKey,'1');
  }
  const accessoryLowDefaultUpdateKey = STORAGE_KEY + '.default-accessoryOreLow-7800';
  if(!localStorage.getItem(accessoryLowDefaultUpdateKey)) {
    if(state.prices.accessoryOreLow === '') state.prices.accessoryOreLow = 7800;
    localStorage.setItem(STORAGE_KEY,JSON.stringify(state));
    localStorage.setItem(accessoryLowDefaultUpdateKey,'1');
  }
  const roughShadowDefaultUpdateKey = STORAGE_KEY + '.default-shadowOre-950';
  if(!localStorage.getItem(roughShadowDefaultUpdateKey)) {
    if(state.prices.shadowOre === '' || state.prices.shadowOre === 1500) state.prices.shadowOre = 950;
    localStorage.setItem(STORAGE_KEY,JSON.stringify(state));
    localStorage.setItem(roughShadowDefaultUpdateKey,'1');
  }
  const removeZeluniumKey = STORAGE_KEY + '.remove-zelunium';
  if(!localStorage.getItem(removeZeluniumKey)) {
    localStorage.setItem(STORAGE_KEY,JSON.stringify(state));
    localStorage.setItem(removeZeluniumKey,'1');
  }
  const accessoryLowStoneDefaultUpdateKey = STORAGE_KEY + '.default-accessoryStone0-34990';
  if(!localStorage.getItem(accessoryLowStoneDefaultUpdateKey)) {
    if(state.prices.accessoryStone0 === '') state.prices.accessoryStone0 = 34990;
    localStorage.setItem(STORAGE_KEY,JSON.stringify(state));
    localStorage.setItem(accessoryLowStoneDefaultUpdateKey,'1');
  }
  const accessoryMediumStoneDefaultUpdateKey = STORAGE_KEY + '.default-accessoryStone1-117500';
  if(!localStorage.getItem(accessoryMediumStoneDefaultUpdateKey)) {
    if(state.prices.accessoryStone1 === '') state.prices.accessoryStone1 = 117500;
    localStorage.setItem(STORAGE_KEY,JSON.stringify(state));
    localStorage.setItem(accessoryMediumStoneDefaultUpdateKey,'1');
  }
  const accessoryHighStoneDefaultUpdateKey = STORAGE_KEY + '.default-accessoryStone2-399000';
  if(!localStorage.getItem(accessoryHighStoneDefaultUpdateKey)) {
    if(state.prices.accessoryStone2 === '') state.prices.accessoryStone2 = 399000;
    localStorage.setItem(STORAGE_KEY,JSON.stringify(state));
    localStorage.setItem(accessoryHighStoneDefaultUpdateKey,'1');
  }
  const accessorySupremeStoneDefaultUpdateKey = STORAGE_KEY + '.default-accessoryStone3-1500000';
  if(!localStorage.getItem(accessorySupremeStoneDefaultUpdateKey)) {
    if(state.prices.accessoryStone3 === '') state.prices.accessoryStone3 = 1500000;
    localStorage.setItem(STORAGE_KEY,JSON.stringify(state));
    localStorage.setItem(accessorySupremeStoneDefaultUpdateKey,'1');
  }
} catch { storageAvailable = false; }
const $ = id => document.getElementById(id);
const fmt = n => new Intl.NumberFormat('en-US',{maximumFractionDigits:2}).format(n);
const z = n => n == null ? 'ยังไม่ทราบราคา' : `${fmt(n)} z`;
const cap = t => t[0].toUpperCase()+t.slice(1);
const ITEM_IDS = {
  weaponStone0:1000430,weaponStone1:1000431,weaponStone2:1000432,weaponStone3:1000433,
  armorStone0:1000434,armorStone1:1000435,armorStone2:1000436,armorStone3:1000437,
  accessoryStone0:1000438,accessoryStone1:1000439,accessoryStone2:1000440,accessoryStone3:1000441,
  weaponOreLow:1000419,weaponOreMedium:1000420,armorOreLow:1000423,armorOreMedium:1000424,
  accessoryOreLow:1000426,accessoryOreMedium:1000427,shadowOre:25728,shadow:25729
};
// Adjacent text provides the item name; empty alt avoids duplicate announcements.
function icon(key, extra = '') {
  return `<img class="item-icon ${extra}" src="assets/items/${ITEM_IDS[key]}.png" width="24" height="24" alt="" decoding="async">`;
}
function name(key) {
  const names = {shadow:'Shadowdecon',shadowOre:'Shadowdecon Ore'};
  if(names[key]) return names[key];
  for(const t of R.TYPES) {
    if(key.startsWith(t+'Stone')) return `${cap(t)} Stone · ${R.GRADES[Number(key.at(-1))]}`;
    if(key.startsWith(t+'Ore')) return `${cap(t)} Ore · ${key.slice((t+'Ore').length)}`;
  }
  return key;
}
function fullName(key) {
  const shadowNames={shadow:'Shadowdecon',shadowOre:'Rough Shadowdecon'};
  if(shadowNames[key])return shadowNames[key];
  for(const t of R.TYPES){
    if(key.startsWith(t+'Stone'))return `${cap(t)} Enhancement Stone (${R.GRADES[Number(key.at(-1))]} Grade)`;
    if(key.startsWith(t+'Ore'))return `${cap(t)} Enhancement Ore (${key.slice((t+'Ore').length)} Grade)`;
  }
  return name(key);
}
function copyName(key, label=name(key)) {
  return `<button type="button" class="copy-item" data-copy-item="${key}" title="คัดลอก: ${fullName(key)}" aria-label="คัดลอกชื่อ ${fullName(key)}">${label}</button>`;
}
let copyNoticeTimer;
function copyNotice(message) {
  const notice=$('copy-notice');
  clearTimeout(copyNoticeTimer);notice.textContent=message;notice.hidden=false;
  copyNoticeTimer=setTimeout(()=>{notice.hidden=true;},3500);
}
async function copyItemName(key) {
  if(!Object.hasOwn(ITEM_IDS,key))return;
  const text=fullName(key);
  let copied=false;
  try { if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(text);copied=true;} } catch {}
  if(!copied){
    const previous=document.activeElement;
    const field=document.createElement('textarea');
    field.value=text;field.readOnly=true;field.className='clipboard-fallback';
    document.body.appendChild(field);
    try {field.select();field.setSelectionRange(0,text.length);copied=document.execCommand('copy');} catch {}
    finally {field.remove();previous?.focus({preventScroll:true});}
  }
  if(copied)copyNotice(`คัดลอกแล้ว: ${text}`);
  else {window.prompt('คัดลอกอัตโนมัติไม่ได้ กรุณาคัดลอกชื่อด้านล่าง',text);copyNotice('เลือกชื่อแล้วกด Ctrl+C เพื่อคัดลอก');}
}
function save() {
  try { localStorage.setItem(STORAGE_KEY,JSON.stringify(state)); storageAvailable=true; }
  catch { storageAvailable=false; }
  $('save-status').textContent=storageAvailable?'✓ บันทึกอัตโนมัติแล้ว':'บันทึกไม่ได้ · ใช้ได้เฉพาะรอบนี้';
}
function invField(key,label) { return `<div><span class="inventory-item-label">${icon(key)}${copyName(key,label)}</span><input type="number" min="0" max="1000000000" step="1" inputmode="numeric" data-inventory="${key}" aria-label="มี ${fullName(key)}" value="${state.inventory[key]}"></div>`; }
function drawInventory() {
  const t=state.type;
  $('inventory-fields').innerHTML=`<div class="inventory-group-label">${cap(t).toUpperCase()} ENHANCEMENT STONE</div><div class="inventory-grid">${R.GRADES.map((g,i)=>invField(`${t}Stone${i}`,g)).join('')}</div><div class="inventory-group-label">${cap(t).toUpperCase()} ENHANCEMENT ORE</div><div class="inventory-grid two">${invField(t+'OreLow','Low Grade')}${invField(t+'OreMedium','Medium Grade')}</div><div class="inventory-group-label">SHADOWDECON</div><div class="inventory-grid two">${invField('shadow','ก้อนสำเร็จรูป')}${invField('shadowOre','Ore / Rough · ก้อนเล็ก')}</div>`;
}
function drawPrices() {
  $('price-fields').innerHTML=R.materialKeys.map(k=>`<div class="price-row"><div class="item-label">${icon(k)}<span>${copyName(k)}${k==='shadowOre'?'<small>Rough Shadowdecon ในภาพตลาด</small>':''}</span></div><input id="price-${k}" type="number" min="0" max="1000000000000" step="any" inputmode="decimal" placeholder="ไม่ซื้อ" aria-label="ราคาต่อชิ้น ${fullName(k)}" data-price="${k}" value="${state.prices[k]}"></div>`).join('');
}
function renderCompare() {
  const c=R.comparison(state);
  $('compare-direct-icon').innerHTML=icon('shadow');
  $('compare-ore-icon').innerHTML=icon('shadowOre');
  $('compare-direct').textContent=z(c.direct);
  $('compare-ore').textContent=z(c.combined);
  const verdict=$('compare-verdict');
  if(c.direct==null||c.combined==null) verdict.textContent='ใส่ราคาก้อนสำเร็จรูปและก้อนเล็ก เพื่อเปรียบเทียบทั้งสองทาง';
  else if(c.direct===c.combined) verdict.textContent='ราคาเท่ากันทั้งสองทาง · เลือกตามความสะดวก';
  else verdict.innerHTML=`${c.direct<c.combined?'✓ ซื้อก้อนสำเร็จรูปคุ้มกว่า':'✓ ซื้อก้อนเล็กไปรวมคุ้มกว่า'}<br><b>ประหยัด ${z(Math.abs(c.direct-c.combined))} / ก้อน</b>`;
  $('break-even').textContent=c.breakEven==null?'ใส่ราคาก้อนสำเร็จรูปเพื่อหาจุดคุ้มทุน':`ก้อนเล็กต้องต่ำกว่า ${z(c.breakEven)} / ชิ้น จึงถูกกว่าซื้อก้อนสำเร็จรูป`;
}
function renderResults() {
  const plan=R.calculate(state), baseline=R.calculate(state,true);
  $('target-name').innerHTML=`<span class="target-item-icon">${icon(state.type+'Stone'+state.grade)}</span><span>${copyName(state.type+'Stone'+state.grade,fullName(state.type+'Stone'+state.grade))} × ${fmt(state.quantity)}</span>`;
  $('total').textContent=plan.total==null?'รอราคา':fmt(plan.total);
  $('unit-cost').textContent=plan.total==null?'ใส่ราคาวัตถุดิบที่ขาด เพื่อคำนวณยอดครบถ้วน':state.quantity?`${z(plan.total/state.quantity)} / อัน · เฉลี่ยตามจำนวนเป้าหมาย`:'ตั้งจำนวนเป้าหมายเพื่อเริ่มคำนวณ';
  $('material-cost').textContent=plan.total==null?`${z(plan.materialCost)} + รอราคา`:z(plan.materialCost);
  $('npc-cost').textContent=z(plan.fees);
  const saved=baseline.total!=null&&plan.total!=null?baseline.total-plan.total:0;
  $('savings').textContent=saved>0?`↘ ของในคลังช่วยลดเงินที่ต้องจ่าย ${z(saved)} · เริ่มจากศูนย์ ${z(baseline.total)}`:plan.total==null?'ⓘ ยังคิดยอดรวมไม่ได้ เพราะวัตถุดิบที่ขาดไม่ได้ระบุราคา':'ⓘ ยอดนี้รวมค่าแลกทุกขั้นแล้ว · ของที่มีไม่คิดมูลค่าซื้อเดิม';
  $('shadow-total').innerHTML=`${fmt(plan.shadowRequired)} <em>ก้อน</em>`;
  $('shadow-additional').innerHTML=`${fmt(plan.shadowAdditional)} <em>ก้อน</em>`;
  $('shadow-detail').textContent=`ซื้อ ${fmt(plan.buy.shadow||0)} · รวมจาก Ore ${fmt(plan.steps.combineShadow)}`;
  const ownedRows=Object.entries(plan.used).filter(([,n])=>n>0);
  $('stock-plan').innerHTML=ownedRows.length?`<div class="stock-plan-heading">✓ ใช้ของจากคลังในแผนนี้ <a href="#recipe">ดูขั้นตอนแลก ↓</a></div>${ownedRows.map(([k,n])=>`<div class="stock-plan-row"><span class="item-label">${icon(k)}${copyName(k)}</span><strong>${fmt(n)} ชิ้น</strong></div>`).join('')}`:'';
  $('stock-plan').hidden=!ownedRows.length;
  const rows=Object.entries(plan.buy).filter(([,v])=>v>0);
  $('shopping-count').textContent=`${rows.length} รายการ`;
  $('shopping-list').innerHTML=rows.length?rows.map(([k,n])=>`<div class="shopping-row"><span class="item-glyph" aria-hidden="true">${icon(k)}</span><div class="shopping-item"><b>${copyName(k)}</b><small>${state.prices[k]===''?'กรุณาใส่ราคา':`${z(state.prices[k])} / ชิ้น`}</small></div><div class="shopping-amount"><strong>${fmt(n)} ชิ้น</strong><small>${state.prices[k]===''?'ยังไม่รวมในยอด':z(n*state.prices[k])}</small></div></div>`).join(''):'<div class="empty-message">✓ ไม่ต้องซื้อวัตถุดิบเพิ่ม'+(plan.fees?' · เตรียมเฉพาะค่าแลก NPC':'')+'</div>';
  const configs=[
    ['combineShadow','รวม Shadowdecon',20,'Shadowdecon Ore',1,'Shadowdecon',0,'Polinn'],
    ['lowOre','กลั่น Low Ore',5,'Low Ore',1,'Low Stone',10000,'Ore Researcher · Gemstone Refining'],
    ['shadow','แลก Low Stone',1,'Shadowdecon',1,'Low Stone',20000,'Ore Researcher · Purchase additional gemstone'],
    ['mediumOre','กลั่น Medium Ore',5,'Medium Ore',1,'Medium Stone',20000,'Ore Researcher · Gemstone Refining'],
    ['lowUpgrade','แลก Medium Stone',3,'Low Stone',1,'Medium Stone',10000,'Ore Researcher · Gemstone Exchange'],
    ['highUpgrade','แลก High Stone',3,'Medium Stone',1,'High Stone',20000,'Ore Researcher · Gemstone Exchange'],
    ['supremeUpgrade','แลก Supreme Stone',3,'High Stone',1,'Supreme Stone',50000,'Ore Researcher · Gemstone Exchange']
  ];
  let order=0;
  const recipeItems={combineShadow:['shadowOre','shadow'],lowOre:[state.type+'OreLow',state.type+'Stone0'],shadow:['shadow',state.type+'Stone0'],mediumOre:[state.type+'OreMedium',state.type+'Stone1'],lowUpgrade:[state.type+'Stone0',state.type+'Stone1'],highUpgrade:[state.type+'Stone1',state.type+'Stone2'],supremeUpgrade:[state.type+'Stone2',state.type+'Stone3']};
  $('recipe-steps').innerHTML=configs.filter(([key])=>plan.steps[key]>0).map(([key,title,a,source,b,target,fee,npc])=>{const n=plan.steps[key];return `<div class="recipe-step"><span class="recipe-order">${++order}</span><div class="recipe-title">${title} <small><span class="recipe-materials"><span>${icon(recipeItems[key][0])}${copyName(recipeItems[key][0],source)} ${fmt(a*n)}</span><span aria-hidden="true">→</span><span>${icon(recipeItems[key][1])}${copyName(recipeItems[key][1],target)} ${fmt(b*n)}</span></span>${npc}</small></div><div class="recipe-fee">${z(n*fee)}<small>${fmt(n)} ครั้ง × ${z(fee)}</small></div></div>`;}).join('')||'<div class="empty-message">'+(state.quantity?'✓ มีหินเป้าหมายครบแล้ว ไม่ต้องแลกเพิ่ม':'ยังไม่มีรายการแลก ตั้งจำนวนเป้าหมายก่อน')+'</div>';
  const stockRows=Object.keys(state.inventory).filter(k=>state.inventory[k]>0 && (k.startsWith(state.type)||k.startsWith('shadow')));
  $('inventory-summary').innerHTML=stockRows.length?'<div class="stock-row"><span>วัตถุดิบ</span><span>ใช้</span><span>คงเหลือ</span></div>'+stockRows.map(k=>`<div class="stock-row"><span>${copyName(k)}</span><span>${fmt(plan.used[k]||0)}</span><span>${fmt(plan.remaining[k]||0)}</span></div>`).join(''):'<p class="field-hint">ยังไม่ได้กรอกของในคลัง</p>';
  $('route-hint').textContent=state.mode==='shadow'?'ใช้ Stone ที่มีและ Shadowdecon / Ore เท่านั้น ไม่ใช้ Enhancement Ore':'ใช้หินที่มี แล้วเลือกผสมเส้นทางแลกที่จ่ายเพิ่มน้อยที่สุด';
  renderCompare();
}
function syncControls() {
  document.querySelectorAll('[data-type]').forEach(b=>{
    b.setAttribute('aria-pressed',String(b.dataset.type===state.type));
    b.querySelector('.item-icon').src=`assets/items/${ITEM_IDS[b.dataset.type+'Stone'+state.grade]}.png`;
  });
  for(const key of ['grade','quantity','mode']) $(key).value=state[key];
}
document.addEventListener('click',async e=>{
  const copyButton=e.target.closest('[data-copy-item]');
  if(copyButton){e.preventDefault();await copyItemName(copyButton.dataset.copyItem);return;}
  const button=e.target.closest('[data-type]');
  if(button){state.type=button.dataset.type;syncControls();drawInventory();save();renderResults();}
});
let pending;
document.addEventListener('input',e=>{
  const el=e.target;
  if(!el.matches('input'))return;
  const valid=el.validity.valid;
  el.classList.toggle('input-invalid',!valid);el.setAttribute('aria-invalid',String(!valid));
  if(!valid){$('save-status').textContent='กรอกจำนวนหรือราคาให้อยู่ในช่วงที่กำหนด';return;}
  if(el.dataset.inventory)state.inventory[el.dataset.inventory]=Number(el.value);
  else if(el.dataset.price)state.prices[el.dataset.price]=Number(el.value)>0?Number(el.value):'';
  else if(el.id==='quantity')state.quantity=Number(el.value);
  else return;
  save(); clearTimeout(pending);pending=setTimeout(renderResults,90);
});
for(const key of ['grade','mode']) $(key).addEventListener('change',()=>{state[key]=key==='grade'?Number($(key).value):$(key).value;if(key==='grade')syncControls();save();renderResults();});
$('clear-inventory').addEventListener('click',()=>{for(const k of Object.keys(state.inventory))if(k.startsWith(state.type)||k.startsWith('shadow'))state.inventory[k]=0;drawInventory();save();renderResults();});
document.querySelectorAll('.nav-item').forEach(a=>a.addEventListener('click',()=>{document.querySelectorAll('.nav-item').forEach(n=>n.classList.toggle('active',n===a));}));
syncControls();drawInventory();drawPrices();renderResults();
if(!storageAvailable)$('save-status').textContent='บันทึกไม่ได้ · ใช้ได้เฉพาะรอบนี้';
